﻿define("epi-languagemanager/widget/command/StartBlank", [
// Dojo
    "dojo/_base/declare",
    "dojo/topic",
    // EPi Framework
    "epi-cms/command/TranslateContent",
    // Resource
    "epi/i18n!epi/cms/nls/languagemanager.gadget"
],
function (
// Dojo
    declare,
    topic,
    // EPi Framework
    TranslateContent,
    // Resource
    res
) {

    // module:
    //      "epi-languagemanager/widget/command/StartBlank"
    // summary:
    //      Used for selecting create language branch options for a page

    return declare([TranslateContent], {

        label: res.createlanguagebranch,

        _onModelChange: function () {
            // summary:
            //      Updates canExecute after the model has been updated.
            // tags:
            //      protected, extensions

            this.set("isAvailable", true);
            this.set("canExecute", true);
        },

        _getNormalizedModel: function () {
            // summary:
            //      Gets a normalized model in order to handle the different possible inputs.
            // tags:
            //      protected, extensions

            var model = this.inherited(arguments);

            if (model && !model.language) {
                model.language = {
                    preferredLanguage: this.model.currentItemData.languageID
                };
            }

            return model;
        },

        _execute: function () {
            // summary:
            //      Publishes a change view request to change to the create language branch view.
            // tags:
            //      protected
            var model = this._getNormalizedModel();

            if (typeof this.executeDelegate === "function") {
                this.executeDelegate(this.model);
            } else {
                var data = {
                    contentData: model.content,
                    languageBranch: model.language.preferredLanguage
                };

                topic.publish("/epi/shell/action/changeview", "epi-languagemanager/contentediting/editors/CreateLanguageBranch", null, data);
            }
        }

    });
});
