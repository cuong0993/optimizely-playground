require({cache:{
'url:epi-languagemanager/component/templates/CompareEditing.html':"﻿<div >\n    <div data-dojo-type=\"dijit/layout/BorderContainer\"\n        data-dojo-props=\"gutters: false, liveSplitters: false\"\n        data-dojo-attach-point=\"layoutContainer\">\n\n        <div data-dojo-attach-point=\"toolbar\"\n            data-dojo-type=\"epi-cms/contentediting/EditToolbar\"\n            data-dojo-props=\"region:'top'\">\n        </div>\n        <div data-dojo-attach-point=\"notificationBar\"\n            data-dojo-type=\"epi-cms/contentediting/NotificationBar\"\n            data-dojo-props=\"region:'top'\"\n            style=\"border-top: 1px solid #999; margin-top: 10px;\">\n\n            <div class=\"epi-notificationBarItem\">\n                <div class=\"epi-notificationBarText\" data-dojo-attach-point=\"contentContainer\">\n                    <p data-dojo-attach-point=\"textContainer\"></p>\n                </div>\n                <div class=\"epi-notificationBarButtonContainer\" data-dojo-attach-point=\"buttonContainer\">\n                    <div data-dojo-attach-point=\"dropDownButton\" data-dojo-type=\"dijit/form/DropDownButton\"\n                        data-dojo-props=\"label: '${res.replaceselectedcontent}', 'class': 'epi-mediumButton'\">\n                        <div data-dojo-attach-point=\"dropDownMenu\" data-dojo-type=\"dijit/DropDownMenu\">\n                            <div data-dojo-type=\"dijit/MenuItem\" data-dojo-attach-point=\"duplicateContentMenuItem\" data-dojo-attach-event=\"onClick:_copyFieldValue\">${res.duplicatecontent}</div>\n                            <div data-dojo-type=\"dijit/MenuItem\" data-dojo-attach-point=\"autoTranslateMenuItem\" data-dojo-attach-event=\"onClick:_copyAndTranslateFieldValue\">${res.autotranslate}</div>\n                        </div>\n                    </div>\n\n                    <a class='epi-visibleLink' data-dojo-attach-event=\"onclick:_onCancel\">${res.closecompare}</a>\n                </div>\n            </div>\n        </div>\n\n        <div data-dojo-type=\"dijit/layout/BorderContainer\"\n            data-dojo-props=\"design:'sidebar', gutters:true, liveSplitters:true, region: 'center'\"\n            data-dojo-attach-point=\"container\">\n\n            <div data-dojo-type=\"dijit/layout/ContentPane\"\n                data-dojo-props=\"splitter:true, region:'leading'\"\n                style=\"width: 50%; overflow: auto; overflow-y: auto !important;\"\n                class=\"compareEditingPane compareEditingLeftPane\"\n                data-dojo-attach-point=\"leftForm\">\n            </div>\n            <div data-dojo-type=\"dijit/layout/ContentPane\"\n                data-dojo-props=\"splitter:true, region:'center'\"\n                style=\"width: 50%; overflow: auto; overflow-y: auto !important;\"\n                class=\"compareEditingPane compareEditingRightPane\"\n                data-dojo-attach-point=\"rightForm\">\n            </div>\n        </div>\n    </div>\n</div>\n"}});
﻿define("epi-languagemanager/component/CompareEditing", [
// Dojo
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/_base/array",
    "dojo/aspect",
    "dojo/promise/all",
    "dojo/Deferred",
    "dojo/dom-style",
    "dojo/query",
    "dojo/topic",
    "dojo/when",
    "dojo/on",

    // Dijit
    "dijit/_TemplatedMixin",
    "dijit/_Widget",
    "dijit/_WidgetsInTemplateMixin",
    "dijit/layout/BorderContainer",     // used in template
    "dijit/layout/ContentPane",         // used in template
    "dijit/registry",
    "dijit/form/DropDownButton",        // used in template
    "dijit/DropDownMenu",               // used in template
    "dijit/MenuItem",                   // used in template
    "dijit/popup",

    // Dojox
    "dojox/widget/Standby",

    // EPi Framework
    "epi/dependency",
    "epi/shell/widget/_ModelBindingMixin",
    "epi/shell/TypeDescriptorManager",

    // CMS
    "epi-cms/contentediting/ContentViewModel",
    "epi-cms/contentediting/EditToolbar",
    "epi-cms/core/ContentReference",
    "epi-cms/contentediting/NotificationBar",
    "epi-cms/contentediting/editors/ContentAreaEditor",

    // Language Manager
    "epi-languagemanager/component/viewmodel/CompareEditingViewModel",

    // Template
    "dojo/text!./templates/CompareEditing.html",

    // Resources
    "epi/i18n!epi/cms/nls/languagemanager.compareediting"
], function (
// Dojo
    declare,
    lang,
    array,
    aspect,
    all,
    Deferred,
    domStyle,
    query,
    topic,
    when,
    on,

    // Dijit
    _TemplatedMixin,
    _Widget,
    _WidgetsInTemplateMixin,
    BorderContainer,
    ContentPane,
    registry,
    DropDownButton,
    DropDownMenu,
    MenuItem,
    popup,

    // Dojox
    Standby,

    // EPi Framework
    dependency,
    _ModelBindingMixin,
    TypeDescriptorManager,

    // CMS
    ContentViewModel,
    EditToolbar,
    ContentReference,
    NotificationBar,
    ContentAreaEditor,

    // Language Manager
    CompareEditingViewModel,

    // Template
    template,

    // Resources
    res
) {
    // summary:
    //      The compare editing controller. That display 2 form editing include:
    //      - Master language content (in readonly mode)
    //      - Current content (can be edited as normal)
    return declare([_Widget, _TemplatedMixin, _WidgetsInTemplateMixin, _ModelBindingMixin], {
        // baseClass: [public] String
        //      The base style class for this widget
        baseClass: "epi-compareEditing",

        // templateString: [pubic] String
        //      The display template for this widget.
        templateString: template,

        // res: Json object
        //      Language resource
        res: res,

        // contextTypeName: String
        //      Type name for the context we can handle
        contextTypeName: "epi.cms.contentdata",

        // currentFormEditing: [pubilc] Object
        //      The instance of viewClass for current content
        currentFormEditing: null,

        // masterFormEditing: [pubilc] Object
        //      The instance of viewClass for master content
        masterFormEditing: null,

        // viewModel: [public] CompareEditingViewModel instance
        //      The view model of this widget.
        viewModel: null,

        // viewParams: [public] Object
        //      The parameters to create view.
        viewParams: null,

        // standby: [protected] Object
        //      Standby widget.
        standby: null,

        // _autoSaveButton: [private] Reference to AutoSaveButton instance
        //      Used to inject AutoSaveButton in our editing toolbar.
        _autoSaveButton: null,

        cacheSynchableProperties: null,

        // [private] boolean
        //      Determine whether the CompareEditing is showing or not.
        _isShowing: false,

        postCreate: function () {
            this.inherited(arguments);

            this.cacheSynchableProperties = {
                leftForm: {},
                rightForm: {}
            };

            this.standby = new Standby({ target: "applicationContainer" });
            document.body.appendChild(this.standby.domNode);

            this.viewParams = this.viewParams || {
                toolbar: this.toolbar,
                contextTypeName: this.contextTypeName,
                selectFormOnCreation: false,
                // Fake object to pass throught the harded code session from EditingBase
                iframeWithOverlay: { overlay: { set: function () { }, destroyDescendants: function () { } } },
                // Override default removeForm method
                removeForm: function () {
                    return true;
                }
            };

            var viewModel = new CompareEditingViewModel();
            this.set("model", viewModel);

            this._viewSettingsManager = dependency.resolve("epi.viewsettingsmanager");

            this.own(
                // Restore pinnable states when the context is going to be changed
                topic.subscribe("/epi/shell/context/request", lang.hitch(this, function (contextParameters, callerData) {
                    var contextService = dependency.resolve("epi.shell.ContextService");
                    var currentContextType = contextService.currentContext.type;

                    if (currentContextType === "epi.cms.languagemanager.compareediting" && contextParameters.uri.indexOf(currentContextType) === -1) {
                        popup.close();

                        this._forceIframeReload = true;

                        // Get saved pinnable states of the tools and navigation panes and then restore them.
                        var profile = dependency.resolve("epi.shell.Profile");
                        when(profile.get("addons-language-manager-settings"), function (settings) {
                            if (!settings) {
                                return;
                            }

                            topic.publish("/epi/layout/pinnable/navigation/toggle", settings.navigationPinned);
                            topic.publish("/epi/layout/pinnable/tools/toggle", settings.toolsPinned);
                        });
                    }
                }))
            );
        },

        startup: function () {
            this.inherited(arguments);

            this.standby.startup();
        },

        onHide: function () {
            this.inherited(arguments);

            this._isShowing = false;
            this.toolbar.domNode.blur();
        },

        resize: function (size) {
            // summary:
            //    Call this to resize a widget, or after its size has changed.
            // tags:
            //    public

            this.inherited(arguments);

            this.layoutContainer.resize(size);
        },

        updateView: function (callerData, ctx, additionalParams) {
            // summary:
            //      Interface method that called from WidgetSwitcher to update view into main region.
            // tags:
            //      public virtual

            this._removeAndDestroyForm();

            this.standby.show();

            when(this._setupForms(), lang.hitch(this, function () {

                // Hide standby
                this.standby.hide();
                this._isShowing = true;

                // Reset AutoSaveButton state
                this._autoSaveButton && this._autoSaveButton._setVisibility(false);
            }));

            this._setupEvents();
        },

        onTabSyncClick: function ($tabMaster, $tabSlave, triggerByLanguageManager) {
            /// <summary>Call after sync-click to tabs on both sides</summary>
        },

        _copyFieldValue: function () {
            /// <summary>Copy field value from master content to current editing language branch</summary>

            if (!this._currrentSelectedField) {
                return;
            }

            var sourceEditor = this.cacheSynchableProperties.leftForm[this._currrentSelectedField],
                valueToCopy = sourceEditor.get("value"),
                targetEditor = this.cacheSynchableProperties.rightForm[this._currrentSelectedField];

            // Do nothing when editor is readonly
            if (!targetEditor || targetEditor.readOnly) {
                return;
            }

            this._setEditorValue(targetEditor, valueToCopy);
        },

        _copyAndTranslateFieldValue: function () {
            /// <summary>Translate field value from master to current language branch</summary>

            if (!this._currrentSelectedField) {
                return;
            }

            var sourceEditor = this.cacheSynchableProperties.leftForm[this._currrentSelectedField],
                valueToTranslate = sourceEditor.get("value"),
                targetEditor = this.cacheSynchableProperties.rightForm[this._currrentSelectedField],
                specialHandling = null;

            // Do nothing when editor is readonly
            if (!targetEditor || targetEditor.readOnly) {
                return;
            }

            /*=====special handling for StringList property which has value represented as an array of string===*/
            if (lang.isArray(valueToTranslate)) {
                valueToTranslate = valueToTranslate.join("$$\r");
                specialHandling = "StringList";
            }
            /*==================================================================================================*/

            if (valueToTranslate) {
                this.standby.show();
                when(this.model.languageManagerStore.executeMethod("TranslateText", null,
                    {
                        text: valueToTranslate,
                        fromLanguageID: this.masterFormEditing.viewModel.languageContext.language,
                        toLanguageID: this.currentFormEditing.viewModel.languageContext.language,
                        specialHandling: specialHandling
                    }),
                    lang.hitch(this, function (result) {
                        if (result.isSuccess) {
                            this._setEditorValue(targetEditor, result.message);
                        }
                    this.standby.hide();
                })
                );
            } else {
                this._setEditorValue(targetEditor, valueToTranslate);
            }
        },

        _setEditorValue: function (editor, value) {
            /// <summary>Set value for an editor widget which conained in editor wrapper</summary>

            // set _grabFocusOnStartEdit to [false] to prevent the current view scroll because we have already sync scroll of left and right editors
            editor.parent._grabFocusOnStartEdit = false;
            editor.parent.startEdit();
            editor.set("value", value);
            editor.parent.tryToStopEditing(true);
        },

        _removeAndDestroyForm: function () {
            // summary:
            //		Check if a form exists so remove from edit layout and destroy it.
            // tags:
            //		private

            // Destroy view (left & right)
            if (this.currentFormEditing) {
                this.currentFormEditing.destroy();
                this.currentFormEditing = null;
            }
            if (this.masterFormEditing) {
                this.masterFormEditing.destroy();
                this.masterFormEditing = null;
            }

            this.currentFormEditingDefer = null;
            this.masterFormEditingDefer = null;
        },

        _getCurrentContentViewModel: function () {
            // TECH NOTE: try to use existing content view model for current form editing, this will sync all data and undo, redo behavior between views
            this._currentEditingModel = null;
            var self = this;
            var parent = this.getParent();
            var allParentViews = parent.getChildren() || [];
            for (var i = 0; i < allParentViews.length; i++) {
                var view = allParentViews[i];
                if (view && view.id !== this.id && view.contextTypeName === "epi.cms.contentdata" && typeof view._getViewModel === "function") {
                    var contentLink = this.model._currentContentContext ? this.model._currentContentContext.id : (this.model._currentContext ? this.model._currentContext.id : null);
                    this._currentEditingModel = view._getViewModel(contentLink);
                    if (this._currentEditingModel) {
                        //TECH NOTE: Because we are going to customize _contentLinkChanged event, so we need to store the original one for restoring later
                        this._currentContentLinkChanged = this._currentEditingModel.onContentLinkChange;
                        this._currentEditingModel.onContentLinkChange = function () {
                            var newContentLink = self._currentEditingModel.get("contentLink");
                            when(self._currentEditingModel.contentDataStore.get(newContentLink)).then(function (currentContent) {
                                self._currentEditingModel.set("contentData", currentContent);
                            });
                        }.bind(this);
                        this.own(
                            aspect.after(this._currentEditingModel, "_contentLinkChanged", function () {
                                // notfiy change to update toolbar
                                self.model.set("contentLinkSyncChange", true);
                            })
                        );
                        this._currentEditingModel.wakeUp();
                    }
                }
            }
        },

        _syncEditorForProperty: function (fieldName, isMaster) {
            // summary:
            //      Sync scroll position as good as possible
            // tag:
            //      private

            var rightEditor = this.cacheSynchableProperties.rightForm[fieldName].domNode;
            var leftEditor = this.cacheSynchableProperties.leftForm[fieldName].domNode;
            /* eslint-disable */
            var masterTop = $(leftEditor).position().top;
            var slaveTop = $(rightEditor).position().top;
            var delta = Math.abs(slaveTop - masterTop);
            var scrollTop = isMaster ? $(".dijitTabContainer", this.leftForm.domNode).scrollTop() : $(".dijitTabContainer", this.rightForm.domNode).scrollTop();

            isMaster ? $(".dijitTabContainer", this.rightForm.domNode).animate({
                scrollTop: scrollTop + delta
            }, 200) : $(".dijitTabContainer", this.leftForm.domNode).animate({
                scrollTop: scrollTop + delta
            }, 200);
            /* eslint-enable */
        },

        _setupForms: function () {
            // summary:
            //      Setup 2 forms (left and right)
            // tags:
            //      private

            var deferred = new Deferred();

            //reset
            this._currentEditingModel = null;
            this._masterViewModel = null;
            this._getCurrentContentViewModel();

            var deferredList = { masterViewModel: this.model.getMasterContentViewModel() },
                self = this;

            if (!this._currentEditingModel) {
                deferredList["currentViewModel"] = this.model.getCurrentContentViewModel();
            }

            all(deferredList).then(lang.hitch(this, function (result) {
                if (result.currentViewModel) {
                    this._currentEditingModel = result.currentViewModel;
                }
                this._masterViewModel = result.masterViewModel;

                // Setup view common method
                function setupView(container, model, isMaster) {
                    var def = new Deferred();
                    var formEditing = new self.viewClass(lang.mixin({
                        editLayoutContainer: container
                    }, self.viewParams));

                    self.own(
                        formEditing,
                        self.connect(formEditing, "onFieldCreated", function (fieldName, editor) {
                            isMaster ? self.cacheSynchableProperties.leftForm[fieldName] = editor : self.cacheSynchableProperties.rightForm[fieldName] = editor;
                            self.connect(editor, "onFocus", function () {
                                self._syncEditorForProperty(fieldName, isMaster);
                                if (isMaster) {
                                    return;
                                }
                                !editor.readOnly && (self._currrentSelectedField = fieldName);
                                self.duplicateContentMenuItem.set("disabled", editor.readOnly);
                                // Disable the auto translate menu item if editor is readonly, or no translation service is available, or editor is ContentArea
                                self.autoTranslateMenuItem.set("disabled", editor.readOnly || self.model.isTranslatingServiceAvailable !== true || editor instanceof ContentAreaEditor);
                            });
                        }),

                        self.connect(formEditing, "onGroupCreated", function (groupName, widget) {
                            if (groupName === "ePiServerCMS_SettingsPanel" && isMaster) {
                                // Register an callback method to disable tools button after form is created.
                                self._disableToolButtons(widget);
                            }
                        }),

                        self.connect(formEditing, "onSetupEditModeComplete", function () {
                            topic.subscribe(formEditing._form.containerLayout.id + "-selectChild", function (widget) {
                                var layoutContainer = isMaster ? self.currentFormEditing._form.containerLayout : self.masterFormEditing._form.containerLayout;
                                var matchedChildren = array.filter(layoutContainer.getChildren(), function (item) {
                                    return item.name === widget.name;
                                });
                                matchedChildren.length && layoutContainer.selectChild(matchedChildren[0]);
                            });
                            def.resolve(formEditing);
                        })
                    );

                    formEditing.onPreviewReady(model, formEditing.ownerDocument, true);

                    return def;
                }

                /// TECH NOTE: We use the default editing view of the content.
                /// If the editing view does not exist, then get the first available view of the content
                /// If there is no view associated with the content, then use 'epi-cms/contentediting/FormEditing' as the default
                var viewKey = "formedit";
                var availableViews = this._getAvailableViews(this._currentEditingModel.contentData.typeIdentifier),
                    view = this._getViewByKey(viewKey, availableViews) || availableViews[0];
                var viewType = view ? view.viewType : "epi-cms/contentediting/FormEditing";

                require([viewType], lang.hitch(this, function (viewClass) {
                    this.viewClass = viewClass;
                    this._setupToolbar();
                    this.currentFormEditingDefer = this.currentFormEditingDefer || setupView(this.rightForm, this._currentEditingModel);
                    this.masterFormEditingDefer = this.masterFormEditingDefer || setupView(this.leftForm, this._masterViewModel, true);

                    all([this.currentFormEditingDefer, this.masterFormEditingDefer]).then(lang.hitch(this, function (forms) {
                        this.currentFormEditing = forms[0];
                        this.masterFormEditing = forms[1];
                        this._autoSaveButton = this.currentFormEditing._autoSaveButton;
                        this._onSetupEditModeComplete();
                        deferred.resolve();
                    }));
                }));
            }));

            return deferred;
        },

        _getViewByKey: function (key, availableViews) {
            // summary:
            //      get a view by its key
            // tags:
            //      private

            return array.filter(availableViews, function (availableView) {
                return availableView.key === key;
            })[0];
        },

        _getAvailableViews: function (dataType) {
            // summary:
            //      get all available views of a content type and return by sortOrder
            // tags:
            //      private

            var availableViews = TypeDescriptorManager.getAndConcatenateValues(dataType, "availableViews"),
                disabledViews = TypeDescriptorManager.getValue(dataType, "disabledViews");

            var filteredViews = array.filter(availableViews, function (availableView) {
                return array.every(disabledViews, function (disabledView) {
                    return availableView.key !== disabledView;
                });
            });
            return filteredViews.sort(function (x, y) {
                return x.sortOrder < y.sortOrder ? -1 : 1;
            });
        },

        _setupEvents: function () {
            // summary:
            //      Setup all events
            // tags:
            //      private

            // Listen undo/redo changes
            var parent = this.getParent(),
                self = this;
            this.own(
                aspect.after(parent, "layout", function () {
                    self.container.resize();
                }, true),
                self.model.watch("contentLinkSyncChange", function () {
                    self.toolbar.set("contentViewModel", self._currentEditingModel);
                    self.toolbar._commands.revertToPublished.set("model", self._currentEditingModel);
                })
            );
        },

        _setupToolbar: function () {
            // summary:
            //      Setup toolbar including PublishActionMenu, AutoSave button, Back button
            // tags:
            //      private

            var viewModel = this._currentEditingModel;

            // Workaround to ignore broadcast undo/redo global event
            var self = this;
            this.toolbar.setItemProperty("undo", "onClick", function () {
                self.currentFormEditing.viewModel.undo();
            });
            this.toolbar.setItemProperty("redo", "onClick", function () {
                self.currentFormEditing.viewModel.redo();
            });

            this.toolbar._commands.revertToPublished.set("model", viewModel);

            lang.mixin(this.toolbar, {
                viewConfigurations: {
                    availableViews: []
                }
            });
            this.toolbar.set("contentViewModel", viewModel);

            this.textContainer.innerHTML = lang.replace(res.comparing,
                {
                    masterLanguageName: this._masterViewModel.contentData.currentLanguageBranch.name,
                    languageName: this._currentEditingModel.contentData.currentLanguageBranch.name
                });

            this._setupToolbarButtons();
        },

        _setupToolbarButtons: function () {
            /// summary:
            //      Setup toolbar buttons and their enable-state based on current selected property
            // tags:
            //      private

            this.duplicateContentMenuItem.set("label", lang.replace(res.duplicatecontent, { name: this._masterViewModel.contentData.currentLanguageBranch.name }));
            this.autoTranslateMenuItem.set("label", lang.replace(res.autotranslate, { name: this._masterViewModel.contentData.currentLanguageBranch.name }));

            // Disable menu items if no translation service is available or no focused property
            this.duplicateContentMenuItem.set("disabled", !this._masterLangElement);
            this.autoTranslateMenuItem.set("disabled", this.model.isTranslatingServiceAvailable !== true || !this._masterLangElement);

            // Because we are using the Notification Bar as a "styling container", so always show it
            domStyle.set(this.notificationBar.domNode, "display", "");
        },

        _onCancel: function () {
            // summary:
            //      Back to on page edit view
            // tags:
            //      private

            // Set flag to force Iframe reload data
            this._forceIframeReload = true;

            // TECH NOTE: We need to restore the _contentLinkChanged to the original if it was changed
            if (this._currentContentLinkChanged && typeof this._currentContentLinkChanged === "function") {
                this._currentEditingModel.onContentLinkChange = this._currentContentLinkChanged;
            }

            var contentLink = new ContentReference(this._currentEditingModel.contentLink).createVersionUnspecificReference();
            topic.publish(
                "/epi/shell/context/request",
                { uri: "epi.cms.contentdata:///" + contentLink },
                { sender: this, forceContextChange: true }
            );

            this._isShowing = false;
        },

        _onSetupEditModeComplete: function () {
            // summary:
            //		Triggerred when the master content editing view is created.
            // tags:
            //		public, callback

            // Run callback methods after view is created
            // For example: Disable tools dropdown buttons.

            this.resize();
            if (this._setupEditModeCompleteCallback) {
                var item;

                // eslint-disable-next-line no-cond-assign
                while (item = this._setupEditModeCompleteCallback.pop()) {
                    var params = item.params,
                        method = item.func,
                        context = item.context;

                    method.apply(context, params);
                }
            }
        },

        _disableToolButtons: function (widget) {
            // summary:
            //      Disable the Tools dropdown button on form editing
            // tags:
            //      private

            if (!this._setupEditModeCompleteCallback) {
                this._setupEditModeCompleteCallback = [];
            }

            this._setupEditModeCompleteCallback.push({
                context: this,
                params: [widget],
                func: function (widget) {
                    // TECH NOTE: Since toolButtons are created by Defer, we don't know when they are available. So we have to check by interval.
                    var disableToolButtonInterval = setInterval(function () {
                        if (widget.contentDetails && widget.contentDetails.domNode) {
                            var toolButtonDOM = query(".dijitDropDownButton", widget.contentDetails.domNode)[0],
                                toolButtons = registry.getEnclosingWidget(toolButtonDOM);

                            !!toolButtons && toolButtons.set("disabled", true);

                            clearInterval(disableToolButtonInterval);
                        }
                    }, 100);
                }
            });
        }
    });
});
