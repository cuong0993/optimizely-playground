﻿define("epi-languagemanager/component/command/_CommandWithOptions", [
// Dojo base
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/aspect",

    // Dijit
    "dijit/popup",
    "dijit/Destroyable",

    // Language manager
    "epi-languagemanager/component/command/CommandBase",
    "epi-languagemanager/widget/CommandSelector"
],
function (
// Dojo base
    declare,
    lang,
    aspect,

    // Dijit
    popupManager,
    Destroyable,

    // Language manager
    CommandBase,
    CommandSelector
) {

    return declare([CommandBase, Destroyable], {

        // label: [public] String
        //      The action text of the command to be used in visual elements.
        label: "",

        category: "context",

        // For contextMenu
        popup: null,
        popupClass: CommandSelector,

        constructor: function (params) {
            this.set("isAvailable", true);
            this.set("canExecute", true);
        },

        _popupSetter: function (/*Object*/popup) {
            // summary:
            //      Customize set method to setting up on the popup
            // tags:
            //      public override

            this.popup = popup;
            this._setupPopup(this.popup);
            this._setupEvent(this.popup);
        },

        _setupPopup: function (/*Object*/popup) {
            // summary:
            //      Initialize popup sub items and do something else.
            // tags:
            //      private

            // Create sub items
            this._setupSubItems(this.model, popup);
        },

        _setupEvent: function (/*Object*/popup) {
            // summary:
            //      Bind event's listeners on the popup
            // tags:
            //      private

            this.own(
                aspect.after(popup, "onItemSelected", lang.hitch(this, function (command) {
                    var parentMenu = popup.parentMenu;
                    if (parentMenu) {
                        parentMenu._cleanUp();
                        popupManager.close(parentMenu);
                    } else {
                        popupManager.close(popup);
                    }

                    this.onItemSelected(command);
                }), true)
            );
        },

        _onModelChange: function () {
            // summary:
            //      Updates the command and sub commands when the model has been updated.
            // tags:
            //      protected

            if (this.popup) {
                this._setupPopup(this.popup);
            }
        },

        _setupSubItems: function (model, popup) {
            // summary:
            //      Setup sub menu items when user click to the command.
            // tags:
            //      protected

            var subCommands = this.getSubCommands(model);

            popup.set("items", subCommands);
        },

        getSubCommands: function (model) {
            // summary:
            //      Get sub menu items
            // tags:
            //      public
        },

        onItemSelected: function (command) {
            // summary:
            //      Callback when a subcommand is selected
            // tags:
            //      public

            command.execute(true);
        }
    });
});
