//>>built
define("epi-languagemanager/ModuleSettings",[],function(){return {};});