define("epi-forms/FormElementStatusChangeInterceptor", [// dojo
"dojo/_base/declare", "dojo/_base/lang", "dojo/aspect", "dojo/when", "dojo/Deferred", "dojo/topic", "dojo/Stateful", "dijit/Destroyable", "epi/dependency", "epi/shell/TypeDescriptorManager", "epi-cms/contentediting/ContentActionSupport", "epi-cms/_ContentContextMixin", "epi-forms/ModuleSettings"], function (declare, lang, aspect, when, Deferred, topic, Stateful, Destroyable, dependency, TypeDescriptorManager, ContentActionSupport, _ContentContextMixin, ModuleSettings) {
  return declare([Stateful, Destroyable, _ContentContextMixin], {
    // summary:
    //      Request interceptor that adds the current project id to all render requests if project mode is enabled
    // tags:
    //      internal
    // store navigate back to FormContainerBlock after publishing an element.
    _navigateInfo: {
      shouldRedirect: false,
      containerContentLink: null
    },
    postscript: function postscript(params) {
      this.inherited(arguments);
      declare.safeMixin(this, params);
      this.contextService = this.contextService || dependency.resolve("epi.shell.ContextService");
      this.own(this.contextService.registerRequestInterceptor(lang.hitch(this, this._onInterceptRequest)));
      aspect.after(this.contextService, "_handleContextLoaded", lang.hitch(this, function () {
        if (!this._navigateInfo.shouldRedirect || !this._navigateInfo.containerContentLink) {
          return;
        }

        var uri = "epi.cms.contentdata:///" + this._navigateInfo.containerContentLink;
        topic.publish("/epi/shell/context/request", {
          uri: uri
        }, {
          forceReload: true,
          sender: this
        });
        this._navigateInfo.shouldRedirect = false;
      })); // if the first load is FormContainerBlock, save it to direct later

      when(this.getCurrentContext(), lang.hitch(this, function (ctx) {
        this._storeFormContainerContentLink(ctx);
      }));
    },
    contentContextChanged: function contentContextChanged(ctx, callerData) {
      // summary:
      //      Handle event when context has changed.
      // tags:
      //      protected
      this.inherited(arguments);

      this._storeFormContainerContentLink(ctx);
    },
    _storeFormContainerContentLink: function _storeFormContainerContentLink(ctx) {
      // summary:
      //      Remember the current FormContainerBlock for navigating back when publish an element.
      // tags:
      //      private
      if (!ctx || !TypeDescriptorManager.isBaseTypeIdentifier(ctx.dataType, ModuleSettings.formContainerContentType)) {
        return;
      }

      this._navigateInfo.containerContentLink = ctx.id;
    },
    _onInterceptRequest: function _onInterceptRequest(contextParams, callerData) {
      // summary:
      //      Request interceptor that redirect to form container block after changing status of form element block
      // tags:
      //      private
      var dfd = new Deferred();

      if (!callerData || !callerData.sender) {
        dfd.resolve();
        return dfd.promise;
      }

      if (callerData.sender.action === ContentActionSupport.saveAction.RequestApproval || callerData.sender.action === ContentActionSupport.saveAction.Publish || callerData.sender.approval != null && callerData.sender.executeMethod !== "cancelChanges") {
        var self = this;
        when(this.getCurrentContent(), function (contentData) {
          if (contentData && ModuleSettings.registeredElementContentTypes.indexOf(contentData.typeIdentifier) > -1) {
            // remember to redirect to FormContainerBlock after content loaded.
            self._navigateInfo.shouldRedirect = true;
          }

          dfd.resolve();
        }, function () {
          dfd.resolve();
        });
        return dfd.promise;
      }

      dfd.resolve();
      return dfd.promise;
    }
  });
});