define("epi-forms/widget/ChoiceItemWithNotification", [// dojo
"dojo/_base/declare", "dojo/_base/lang", "dojo/when", "dojo/aspect", "dojo/Deferred", // epi
"epi/dependency", // epi-addons
"epi-forms/widget/ChoiceItemWithNumberSpinner", "epi/shell/_ContextMixin", "epi-forms/notification/RetentionPolicyNotification"], function ( // dojo
declare, lang, when, aspect, Deferred, //epi
dependency, // epi-addons
ChoiceItemWithNumberSpinner, _ContextMixin, RetentionPolicyNotification) {
  // module:
  //      epi-forms/widget/ChoiceItemWithNotification
  // summary:
  //      This widget used for edtior with extend widget and notification
  // tags:
  //      public
  return declare([ChoiceItemWithNumberSpinner, RetentionPolicyNotification, _ContextMixin], {
    _notification: null,
    _notificationMessage: null,
    postCreate: function postCreate() {
      this.inherited(arguments); // load notification and server which were registered before

      this._notification = this._notification || dependency.resolve("epi-forms.retentionpolicynotification");
      this.retentionpolicyNotificationService = this.retentionpolicyNotificationService || dependency.resolve("epi-forms.retentionpolicyservice");

      this._getNotificationMessage();
    },
    _setupExtendedWidget: function _setupExtendedWidget(
    /*Object*/
    item) {
      // summary:
      //      Override base method to show notification after onchange event
      // item: [Object]
      //      Item data object used to build extended widget.
      // tags:
      //      private
      this.inherited(arguments);
      when(this._getExtendedWidget(), lang.hitch(this, function (extendedWidget) {
        if (!extendedWidget || !item) {
          return;
        }

        this.own(aspect.after(extendedWidget, "onChange", lang.hitch(this, function () {
          when(this._getNotificationMessage()).then(function () {
            var value = {
              isModifyingPolicy: true,
              notificationMessage: this._notificationMessage
            };

            this._notification.set("value", value);
          }.bind(this));
        })));
      }));
    },
    _getNotificationMessage: function _getNotificationMessage() {
      // summary:
      //      Get notification message ansynchnorously
      // return a promise that gets resolved when message loading finish
      // tags:
      //      private
      var deferred = new Deferred();

      if (this._notificationMessage) {
        deferred.resolve(this._notificationMessage);
      } // at first loading, get and store notification message for later use.
      // to avoid multiple server request


      when(this.getCurrentContext()).then(function (context) {
        when(this.retentionpolicyNotificationService.getNotificationMessage(context.id)).then(function (message) {
          this._notificationMessage = message;
          deferred.resolve(this._notificationMessage);
        }.bind(this));
      }.bind(this));
      return deferred;
    }
  });
});