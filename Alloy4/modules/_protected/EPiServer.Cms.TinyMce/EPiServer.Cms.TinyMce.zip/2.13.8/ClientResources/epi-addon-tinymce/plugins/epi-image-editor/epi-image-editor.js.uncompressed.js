define("epi-addon-tinymce/plugins/epi-image-editor/epi-image-editor", [
    "epi/routes",
    "epi-addon-tinymce/tinymce-loader",
    "epi-cms/legacy/LegacyDialogPopup",
    "epi/i18n!epi/cms/nls/episerver.cms.tinymce.plugins.epiimageeditor"
], function (routes, tinymce, LegacyDialogPopup, pluginResources) {

    tinymce.PluginManager.add("epi-image-editor", function (editor) {

        var imageNode;

        editor.addCommand("mceEPiImageEditor", function () {

            var selectedNode = imageNode;
            var imgSrc = editor.dom.getAttrib(selectedNode, "src");
            var sizeIsSpecified;

            if (!imgSrc) {
                return;
            }

            var onDialogComplete = function (returnData) {
                if (returnData) {
                    var queryString = "img[src^=\"" + imgSrc + "\"]",
                        imgNodes = editor.dom.select(queryString);

                    if (sizeIsSpecified) {
                        editor.dom.setAttrib(imgNodes, "width", returnData.actualWidth);
                        editor.dom.setAttrib(imgNodes, "height", returnData.actualHeight);
                    }

                    editor.dom.setAttrib(imgNodes, "src", returnData.src);

                    //Wrap all changes as one undo level
                    editor.undoManager.add();
                }

                editor.fire("CloseWindow", {
                    win: null
                });
            };

            var dialogArguments = {
                src: imgSrc
            };

            sizeIsSpecified = editor.dom.getAttrib(selectedNode, "width");

            // Resolve the path to the image editor dialog and append the page context parameters to the query string.
            var dialogURL = routes.getActionPath({
                moduleArea: "LegacyCMS",
                path: "Edit/ImageEditor/ImageEditor.aspx",
                src: imgSrc
            });

            var dialog = new LegacyDialogPopup({
                url: dialogURL,
                onCallback: onDialogComplete,
                dialogArguments: dialogArguments,
                autoFit: true,
                showCancelButton: true,
                showLoadingOverlay: false
            });
            dialog.show();
            editor.fire("OpenWindow", {
                win: null
            });

        });

        // Register buttons
        editor.addButton("epi-image-editor", {
            title: pluginResources.title,
            cmd: "mceEPiImageEditor",
            icon: "editimage",
            onPostRender: function () {
                // Add a node change handler, selects the button in the UI when a image is selected
                editor.on("NodeChange", function (e) {
                    //Prevent tool from being activated as objects represented as images.
                    var isStandardImage = e.element.tagName === "IMG" && editor.dom.getAttrib(e.element, "class").indexOf("mceItem") === -1;
                    var isImageFigure = e.element.tagName === "FIGURE" && /\bimage\b/i.test(e.element.className);
                    this.active(isStandardImage || isImageFigure);
                    this.disabled(!isStandardImage && !isImageFigure);

                    //Set or reset imageNode to the node cause Image Editor command enabled
                    imageNode = isStandardImage ? e.element : isImageFigure ? editor.dom.select("img", e.element)[0] : null;
                }.bind(this));
            }
        });

        return {
            getMetadata: function () {
                return {
                    name: "Image Editor (epi)",
                    url: "https://www.episerver.com"
                };
            }
        };
    });
});
